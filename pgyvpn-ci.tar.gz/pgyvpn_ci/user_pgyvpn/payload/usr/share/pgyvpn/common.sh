#!/bin/sh
#全局变量，表示当前脚本所在绝对路径
source /usr/share/pgyvpn/third.sh

rawurlencode() {
    local string="${1}"                                 
    local strlen=${#string}                             
    local encoded=""                                    
    local pos c o                                       
                                                        
    let strlen=$strlen-1                                
    for pos in $(seq 0 $strlen); do                     
            c=${string:$pos:1}                          
            case "$c" in [-_.~a-zA-Z0-9] )              
                    o="${c}" ;;                         
            * )                                         
                    o=$(printf '%%%02x' "'$c")          
            esac                                        
                                                        
            encoded=$encoded"${o}"                      
    done                                                
    echo "$encoded"                               
}                           

# Returns a string in which the sequences with percent (%) signs followed by
# two hex digits have been replaced with literal characters.
rawurldecode() {
    REPLY="" 
    # This is perhaps a risky gambit, but since all escape characters must be
    # encoded, we can replace %NN with \xNN and pass the lot to printf -b, which
    # will decode hex for us
    
    # You can either set a return variable (FASTER)
    printf -v REPLY '%b' "${1//%/\\x}" 
    #+or echo the result (EASIER)... or both... :p
    echo "${REPLY}"
}

url_decode() {
    echo -e "$(echo -n "$1" | sed 's/+/ /g;s/%\(..\)/\\x\1/g;')"
    return 0
}

getUA(){
    arch=$(uname -m)
    echo "PgyVisitorEnt/6.9.0 (Linux;$arch;$gHost)"
}

ReadIni() {
  fid=$1
  section=$2
  option=$3

  test ! -f $fid && echo "ini not exist" && return 2
  if [ $# -eq 3 ]; then
    local src=$(cat $fid | awk '/\['$section'\]/{f=1;next} /\[*\]/{f=0} f' | #找出section下的所有内容
      grep $option |                                                         # 匹配option的行
      grep '=' |                                                             # 看看是不是存在=
      cut -d'=' -f2 |                                                        # 获取对应的值
      cut -d'#' -f1 |                                                        # 去除注释
      cut -d';' -f1 |                                                        #去除注释
      awk '{gsub(/^\s+|\s+$/, "");print}')                                   #去掉最前面的空格
    test ${#src} -eq 0 && return 2                                           #读取到有效数据 返回状态码0
    echo $src
    return 0
  else
    return 2
  fi
}

WriteIni() {
  fid=$1
  section=$2
  option=$3
  value=$4

  if [ "${fid##*.}" != "ini" ]; then
    echo "not an ini file"
    return 2
  fi

  if [ ! -f "$fid" ]; then
    echo "ini not exist"
    return 2
  fi

  if [ $# -ne 4 ]; then
    echo "invalid args"
    return 2
  fi

  # 查找 section 起始行号
  section_start=$(awk "/^\[$section\]/ { print NR; exit }" "$fid")
  if [ -z "$section_start" ]; then
    echo "no section [$section]"
    return 2
  fi

  # 查找 section 结束行号（下一个 section）
  section_end=$(awk -v start=$section_start 'NR > start && /^\[.*\]/ { print NR; exit }' "$fid")
  if [ -z "$section_end" ]; then
    section_end=$(wc -l < "$fid")
    section_end=$((section_end + 1))
  fi

  # 查找 option 所在的行号
  option_line=$(awk -v start=$section_start -v end=$section_end -v opt="$option" '
    NR > start && NR < end {
      if ($0 ~ "^[[:space:]]*" opt "[[:space:]]*=") print NR
    }' "$fid")

  if [ -z "$option_line" ]; then
    # 没有 option，插入到 section 最后一个行之后
    insert_line=$((section_end - 1))
    sed -i "${insert_line}a\\    $option = $value" "$fid"
    return 0
  fi

  # 更新已有的值
  # 提取该行并替换 value（保留注释）
  current_line=$(sed -n "${option_line}p" "$fid")
  comment=$(echo "$current_line" | grep -o '[#;].*')
  new_line="    $option = $value"
  [ -n "$comment" ] && new_line="$new_line $comment"

  sed -i "${option_line}s|.*|$new_line|" "$fid"
  return 0
}


# JSON 转义函数
escape_json() {
    echo "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e 's/\//\\\//g'
}

# 处理嵌套json
extract_json_object_by_key() {
  local key="$1"
  local input="$2"
  echo "$input" | awk -v key="$key" '
    BEGIN { RS=""; FS="" }
    {
      pattern = "\"" key "\"[[:space:]]*:[[:space:]]*\\{"
      if (match($0, pattern)) {
        start = RSTART + RLENGTH - 1
        depth = 1
        out = "{"
        for (i = start + 1; i <= length($0); i++) {
          c = substr($0, i, 1)
          out = out c
          if (c == "{") depth++
          else if (c == "}") depth--
          if (depth == 0) break
        }
        print out
      }
    }
  '
}

# 获取json结构key对应的value
get_val_by_key() {
  target_key="$1"
  json_input="$2"

  # 去除换行变成单行 JSON
  line=$(echo "$json_input" | tr -d '\n')

  # 使用兼容 sed 提取 key 对应值
  raw_value=$(echo "$line" | sed -n 's/.*"'"$target_key"'"[[:space:]]*:[[:space:]]*\("[^"]*"\|[^,}]*\).*/\1/p')

  # 去除外层引号，处理转义字符
  echo "$raw_value" | sed '
    s/^"//;
    s/"$//;
    s/\\"/"/g;
    s/\\\\/\\/g;
    s/\\n/\n/g;
    s/\\t/\t/g;
    s/\\r/\r/g;
    s/\\\//\//g'
}

# 拼接返回json
format_json() {
  body=$1
  jret="{${body},\"retcode\": 0}"
  echo $jret
}

# 拼接json key value
format_json_key_val() {
    key="$1"
    val="$2"
    json_input="${3:-{}}"

    # 修剪尾部多余的右花括号
    json_input=$(echo "$json_input" | sed 's/}*$//')
    json_input="$json_input}"

    # 如果是true、false、null，不加引号；否则都加引号（包括数字和IP）
    case "$val" in
        true|false|null) val_str="$val" ;;
        ''|*[!0-9]*) val_str="\"$(echo "$val" | sed 's/"/\\"/g')\"" ;;  # 包含非数字：加引号
        *) val_str="$val" ;;  # 纯数字
    esac

    if echo "$json_input" | grep -q "\"$key\"[[:space:]]*:"; then
        # 更新已有key的值
        echo "$json_input" | sed "s#\"$key\"[[:space:]]*:[^,}]*#\"$key\": $val_str#"
    else
        # 新增key，插入到最后一个}
        sed_expr='s#}$#,\
  "'"$key"'": '"$val_str"'\
}#'
        echo "$json_input" | sed "$sed_expr"
    fi
}

# 从rpc返回结果中提取body字段
extract_body_field() {
  echo "$1" | awk '
    BEGIN {
      val = ""
      found = 0
    }
    {
      while (match($0, /"body"[[:space:]]*:[[:space:]]*"/)) {
        $0 = substr($0, RSTART + RLENGTH)  # 跳过 "body": "
        len = length($0)
        in_escape = 0
        for (i = 1; i <= len; i++) {
          c = substr($0, i, 1)
          if (in_escape) {
            if (c == "n") val = val "\n"
            else if (c == "t") val = val "\t"
            else if (c == "r") val = val "\r"
            else if (c == "\"") val = val "\""
            else if (c == "\\") val = val "\\"
            else val = val c
            in_escape = 0
          } else if (c == "\\") {
            in_escape = 1
          } else if (c == "\"") {
            found = 1
            break
          } else {
            val = val c
          }
        }
      }
    }
    END {
      if (found) {
        # 输出单行（去掉换行）
        gsub(/\n/, " ", val)
        gsub(/[[:space:]]+/, " ", val)
        print val
      }
    }
  '
}

function get_ip(){
    local ipaddr=$(ip -4 addr show br-lan | awk '/inet/{print $2}' | cut -d'/' -f1)

    # # 使用grep和awk从ifconfig输出中提取eth0的IPv4地址  
    # ipv4_address=$(ifconfig | grep -A 10 '^eth0' | grep 'inet addr:' | awk '{print $2}' | cut -d: -f2)  
    
    # # 去除inet addr:后面的空格  
    # ipv4_address="${ipv4_address# }"  
    
    echo "$ipaddr"
}

write_log() {
    echo $* >> $gloginstallpath
}
