# 蒲公英（pgyvpn）云编译集成包

把已经在本机调好的蒲公英（`v14` 固件里的版本）搬进源码树，让 GitHub Actions 云编译出来的
固件**直接自带**蒲公英：菜单在「穿透服务」组、和 zerotier 并列、页面顶部系统信息正常。

## 这个包里是什么

```
pgyvpn_ci/
├── apply.sh              # 打补丁脚本（幂等，可重复执行）
└── user_pgyvpn/
    ├── Makefile          # 插件 Makefile（romfs 阶段把 payload 铺进去）
    └── payload/          # 22 个文件：二进制 + 脚本 + 两个网页
```

## 仓库里怎么用

你的 `walter935581890/walter-padavan` 仓库根目录已经有 `pgyvpn-ci.tar.gz`，workflow 里就是：

```yaml
tar -xzf "$GITHUB_WORKSPACE/pgyvpn-ci.tar.gz" -C /tmp
sh /tmp/pgyvpn_ci/apply.sh /opt/rt-n56u
```

**所以只要把本包生成的 `pgyvpn-ci.tar.gz` 覆盖仓库里那个同名文件**，4 个 workflow 一行都不用改。

```bash
git clone https://github.com/walter935581890/walter-padavan.git
cd walter-padavan
cp /path/to/pgyvpn-ci.tar.gz .          # 覆盖旧的
git add pgyvpn-ci.tar.gz
git commit -m "pgyvpn: 换成菜单归位版，挂到穿透服务组"
git push
```

也可以直接在 GitHub 网页上 `Add file → Upload files` 覆盖同名文件。

## apply.sh 做了什么（全部幂等）

1. 铺 `trunk/user/pgyvpn/`（payload + Makefile）。payload 里带
   `lib/ld-musl-mipsel-sf.so.1 -> ../usr/lib/pgyvpn/libc.so` 这个软链——
   蒲公英的二进制是 musl 链接的，固件本体是 uClibc，缺这个 loader 它们根本起不来；
   Makefile 里另有兜底：软链不存在才创建，已存在就原样保留。
2. `trunk/user/Makefile`：在 `dir_y += scripts` 后加
   `dir_$(CONFIG_FIRMWARE_INCLUDE_PGYVPN) += pgyvpn`（必须排在内置 www 之后）。
3. `trunk/build_firmware_modify`：加 `PGYVPN=y` 时自动写
   `CONFIG_FIRMWARE_INCLUDE_PGYVPN=y` 到 `.config`。
4. `trunk/user/scripts/dev_init.sh`：`mtd_storage.sh fill` 之后调
   `/usr/bin/pgyvpn_install.sh`（铺账号/路由/自愈脚本），再后台拉起
   `/usr/bin/pgyvpn_boot.sh` —— 启动器先等 `br0` 拿到 IP 再登录，**不依赖
   `/etc/storage/started_script.sh`**（那个文件一旦有语法错误，busybox sh 会整份中止，
   追加在后面的自启段落就永远不执行；v14 实测就是这么踩的），最后转入常驻守卫。
5. `www/state.js`：把蒲公英挂进「穿透服务」组（和 zerotier 同一组），并从
   「系统管理」组摘掉旧位置；组的索引**不是写死的**。
6. `www/Advanced_zerotier.asp`（4.4 系）：去掉页内写死的旧标签条，改成动态标签栏。
7. `www/Advanced_web.asp`（3.4 系）：「自定义菜单选项」页里那一行开关改成
   「穿透服务」并常显（复用 `nvram w_ss`，它在 httpd 的 nvram 白名单里）。
8. 自检：锚点、括号平衡、关键字符串全部打印出来。

## 组索引是自动探测的（重点）

4.4 系和 3.4 系 fork 的菜单编号完全不同：

| 源码树 | 穿透服务组 | 二级菜单槽 | zerotier 页里写的 |
|--------|-----------|-----------|------------------|
| padavan-4.4 | `tablink[16]` | `menuL2_link[17]` | `show_menu(5,17,0)` |
| Padavan-3.4 | `tablink[14]` | `menuL2_link[15]` | `show_menu(5,15,4)` |

脚本先读 `Advanced_zerotier.asp` 里的 `show_menu(5,L2,x)` 反推 `G = L2-1`，
再回 `state.js` 里核对 `tablink[G]` 确实挂着 zerotier；不一致就用正则扫，
最后兜底 `G=16`。同一个包扔给两个 fork 都能对。

`www/pgyvpn.asp` 里也不写死页签序号：运行时扫一遍 `tablink[]` 找到自己，
再在 `menuL2_link[]` 里找本组的槽位，然后 `show_menu(5, 该槽, 该序号)`。

## 二级菜单兜底

如果某个 fork 关了 zerotier、穿透服务组一个应用都没有（`menuL2_link[L2]` 为空），
注入代码会在运行时把「穿透服务」入口追加到二级菜单末尾，保证蒲公英页面点得到：

```js
var reuse = (menuL2_link[L2] == tablink[G][1]);
if (!reuse) { menuL2_title.push("<#menu5_30#>"); menuL2_link.push(tablink[G][1]); }
```

3.4 系「穿透服务」总开关（`w_ss`）关掉时，注入代码直接不挂菜单，
`state.js` 里 `if (w_ss == '0')` 那块已经把整组（含蒲公英）隐藏掉。

## 本地验证结果

- `padavan-4.4` 源码树：`git diff` = 5 files, +32/−15；连跑三次，第二、三次输出「已改: 无」。
- `Padavan-3.4` 源码树：`git diff` = 5 files；连跑三次，第二、三次输出「已改: 无」。
- 两棵树的 `state.js` 花括号/圆括号平衡均 True，`pgyvpn.asp` 里 `<div id="Loading">` 存在。

## 编译时的注意事项

- `build_firmware_modify` 的参数照旧（如 `B70` / `T1HC5661`）。
- workflow 里 `enable_pgyvpn=true` 才会把 `CONFIG_FIRMWARE_INCLUDE_PGYVPN=y` 写进 `.config`；
  `false` 时插件不参与 romfs，固件里不会多出蒲公英。
- 插件本体约 6MB（含 openssl/libstdc++ 等 so），注意固件空间余量。
